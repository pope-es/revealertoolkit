#ifndef __util_h
#define __util_h

int bwrite(int fd, unsigned char *buf, int len);

#endif
